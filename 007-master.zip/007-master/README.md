# 007.PY (ONLY USE VPS - SPOOF) *****
Layer 7 USE: python2 007.py http://targetsite -w 69 -s 4165


----------------

# DOWNLOAD SCRİPT COMMAND:
wget https://raw.githubusercontent.com/B0RU70/007/master/007.py


# Tested Script:
![007 ddos,ddos,layer7](https://2.bp.blogspot.com/-Ufvm6a1bfyM/XABc1h2BB8I/AAAAAAAAFjQ/gaJiiaXlchwW74V9rKuNylJcQlAPffSFQCLcBGAs/s1600/Ekran%2Bg%25C3%25B6r%25C3%25BCnt%25C3%25BCs%25C3%25BC_2018-11-30_00-39-24.png)


EDİTED BY B0RU70
